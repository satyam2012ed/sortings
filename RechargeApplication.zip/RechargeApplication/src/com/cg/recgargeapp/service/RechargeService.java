package com.cg.recgargeapp.service;

import com.cg.recgargeapp.bean.CustomerBean;
import com.cg.recgargeapp.dao.RechargeApplicationDao;
import com.cg.recgargeapp.exception.RechargeException;

public class RechargeService implements IRechargeService{

	@Override
	public String insertRechargeDetails(CustomerBean customerbean) throws RechargeException {
		RechargeApplicationDao rechargedao = new RechargeApplicationDao();
		System.err.println("Inside Service");
		return rechargedao.insertRechargeDetails(customerbean);
	}

	
	
}
