package com.cg.recgargeapp.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.recgargeapp.exception.RechargeException;

public class DbUtil {
	
	static Connection con;
	public static Connection getConnection() throws RechargeException
	{
		
		try {
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg220","training220");
			
		} catch (SQLException e) {
			throw new RechargeException("Error in database connection"+e.getMessage());
		}
		
		return con;		
	}
	

}
