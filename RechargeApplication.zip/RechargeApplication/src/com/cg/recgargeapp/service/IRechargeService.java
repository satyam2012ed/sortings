package com.cg.recgargeapp.service;

import com.cg.recgargeapp.bean.CustomerBean;
import com.cg.recgargeapp.exception.RechargeException;

public interface IRechargeService {
	
	public abstract String insertRechargeDetails(CustomerBean customerbean) throws RechargeException;


}
