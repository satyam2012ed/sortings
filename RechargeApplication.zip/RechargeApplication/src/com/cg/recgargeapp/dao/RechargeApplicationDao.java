package com.cg.recgargeapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.recgargeapp.bean.CustomerBean;
import com.cg.recgargeapp.exception.RechargeException;
import com.cg.recgargeapp.service.DbUtil;

public class RechargeApplicationDao implements IRechargeApplicationDao {

	@Override
	public String insertRechargeDetails(CustomerBean customerbean) throws RechargeException {
		Connection con = DbUtil.getConnection();
		String s=null;
		PreparedStatement preparedstatement;
		PreparedStatement preparedstatement_rid;
		ResultSet rs,rs1;
		try {
			
			preparedstatement = con.prepareStatement(IQueryMapper.INSERT_QUERY);
			
			preparedstatement.setString(1, customerbean.getCustomer_name());
			preparedstatement.setLong(2, customerbean.getMobile());
			preparedstatement.setInt(3, customerbean.getAmount());
			preparedstatement.setString(4, customerbean.getPlan_name());
			preparedstatement.executeUpdate();
			
			preparedstatement_rid = con.prepareStatement(IQueryMapper.GET_RID);
			rs = preparedstatement_rid.executeQuery();
		
			
		} 
		catch (SQLException e) 
		{
			throw new RechargeException("Exception raised while inserting into database");
		}
		try 
		{
			
			int a;
			rs.next();
			
			a = rs.getInt(1)-1;
			
			s = "Your mobile is recharged with "+customerbean.getPlan_name()+" and id is "+a;
			
		} 
		catch (SQLException e) 
		{
			throw new RechargeException("Exception in getting the final output string");
		}
		
		return s;
	}

}
