package com.cg.recgargeapp.dao;

public interface IQueryMapper {
	
	final static String INSERT_QUERY = "INSERT INTO RechargeApplication VALUES(?,?,?,?,rid_seq.NEXTVAL,SYSDATE)";
	final static String GET_RID = "SELECT rid_seq.NEXTVAL FROM DUAL";

}
