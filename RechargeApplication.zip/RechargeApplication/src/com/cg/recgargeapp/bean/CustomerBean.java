package com.cg.recgargeapp.bean;

public class CustomerBean {

	private String customer_name;
	private long mobile;
	private int amount;
	private String plan_name;
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getPlan_name() {
		return plan_name;
	}
	public void setPlan_name(String plan_name) {
		this.plan_name = plan_name;
	}
	
	public CustomerBean(String customer_name, long mobile, int amount, String plan_name) {
		super();
		this.customer_name = customer_name;
		this.mobile = mobile;
		this.amount = amount;
		this.plan_name = plan_name;
	}
	
	public CustomerBean() {
		super();
	}
	
	
	
}
