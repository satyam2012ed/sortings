package com.cg.recgargeapp.ui;

import java.util.Scanner;

import com.cg.recgargeapp.bean.CustomerBean;
import com.cg.recgargeapp.exception.RechargeException;
import com.cg.recgargeapp.service.RechargeService;

public class ClientUI {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		int option;
		String message;
		CustomerBean customer = new CustomerBean();
		RechargeService rechargeservice = new RechargeService();
		System.out.println("1. Make a Recharge.\n2. Exit");
		option = scanner.nextInt();
		switch(option)
		{
		case 1: 
			System.out.println("Enter the customer name : ");
			String name = scanner.next();
			System.out.println("Enter the mobile number : ");
			Long number = scanner.nextLong();
			System.out.println("Enter the amount : ");
			int amount = scanner.nextInt();
			System.out.println("Select plan name\nRC99-[1] RC200-[2] RC500-[3]");
			System.out.println("Enter the plan number :");
			int plan_choice = scanner.nextInt();
			String plan;
			if(plan_choice==1)
				plan = "RC99";
			else if(plan_choice==2)
				plan = "RC200";
			else
				plan = "RC500";
			customer.setCustomer_name(name);
			customer.setMobile(number);
			customer.setAmount(amount);
			customer.setPlan_name(plan);
			try 
			{
				
				message = rechargeservice.insertRechargeDetails(customer);
				
				System.out.println(message);
			} 
			catch (RechargeException e) 
			{
				System.out.println("Error while making the recharge");
			}
			break;
		case 2:
			System.out.println("EXITING..!!!");
			break;
		default:
			System.out.println("Invalid Option");
			
		}
		
	}

}
