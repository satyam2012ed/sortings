package com.cg.recgargeapp.exception;

public class RechargeException extends Exception {

	public RechargeException() {
		// TODO Auto-generated constructor stub
	}

	public RechargeException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
}
