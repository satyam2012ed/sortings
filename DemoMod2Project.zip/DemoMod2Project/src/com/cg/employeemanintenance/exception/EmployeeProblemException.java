package com.cg.employeemanintenance.exception;

public class EmployeeProblemException extends Exception
{

	public EmployeeProblemException(String message) {
		super(message);
	}
}
