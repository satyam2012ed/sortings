package com.cg.employeemanintenance.service;

import com.cg.employeemanintenance.bean.EmployeeBean;
import com.cg.employeemanintenance.dao.EmployeeDaoImpl;
import com.cg.employeemanintenance.dao.IEmployeeDAO;
import com.cg.employeemanintenance.exception.EmployeeProblemException;

public class EmployeeServiceImpl implements IEmployeeService{

	IEmployeeDAO empDao=null;
	@Override
	public boolean addEmployeeDetails(EmployeeBean employee) throws EmployeeProblemException {
		//delegate the call to dao class
		empDao=new EmployeeDaoImpl();
		
		return empDao.addEmployeeDetails(employee);
	}

}
