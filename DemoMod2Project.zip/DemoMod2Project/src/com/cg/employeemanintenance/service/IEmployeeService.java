package com.cg.employeemanintenance.service;

import com.cg.employeemanintenance.bean.EmployeeBean;
import com.cg.employeemanintenance.exception.EmployeeProblemException;

public interface IEmployeeService {

	public abstract boolean addEmployeeDetails(EmployeeBean employee)throws EmployeeProblemException;
}
