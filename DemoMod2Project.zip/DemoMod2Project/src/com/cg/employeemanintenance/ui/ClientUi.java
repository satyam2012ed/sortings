package com.cg.employeemanintenance.ui;

import java.util.Scanner;

import com.cg.employeemanintenance.bean.EmployeeBean;
import com.cg.employeemanintenance.exception.EmployeeProblemException;
import com.cg.employeemanintenance.service.EmployeeServiceImpl;
import com.cg.employeemanintenance.service.IEmployeeService;

public class ClientUi {

	public static void main(String[] args) {
		
		System.out.println("---Cg Employee Portal----");
		System.out.println();
		//System.out.printf();
		System.out.println("1. add employee details");
		System.out.println("2. Search employee details by id");
		System.out.println("3. view All Employee details");
		System.out.println("4. exit");
		System.out.println();
		System.out.println("enter option :");
		Scanner scanner=new Scanner(System.in);
		int option=scanner.nextInt();
		//ClientUi client=new ClientUi();
		switch(option){
		case 1:
			System.out.println("enter name ");
			String name=scanner.next();
			System.out.println("enter city ");
			String city=scanner.next();
			System.out.println("enter mobile ");
			Long mobile=scanner.nextLong();
			
			EmployeeBean employee=new EmployeeBean();
			employee.setCity(city);
			employee.seteName(name);
			employee.setMobile(mobile);
			
			try {
				boolean status=new ClientUi().addEmployee(employee);
				if(status == true){
					System.out.println("data is inserted");
				}
			} catch (EmployeeProblemException e) {
				System.err.println("exception: "+e.getMessage());
			}
		}
	}

	IEmployeeService empServ=null;
	public boolean addEmployee(EmployeeBean employee) throws EmployeeProblemException{
		//no db logic
		//no valid ..
		//delegate the call to service
		//layer along with the data(emp obj) to be validated
		empServ=new EmployeeServiceImpl();
		//validation - on no error call below method
		
		
		return empServ.addEmployeeDetails(employee);
	}
	
	
}
