package com.cg.employeemanintenance.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.employeemanintenance.exception.EmployeeProblemException;

public class Dbutil {

	static Connection conn=null;
	
	public static Connection estabblishConnection() throws SQLException{
		
		conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","pass");
		
		return conn;
	}
}
