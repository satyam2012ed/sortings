package com.cg.employeemanintenance.dao;

public interface IQueryMapper {
	public static final String INSERT_QUERY="INSERT INTO EmployeeDetails1 values(emp_seq1.NEXTVAL,?,?,?,SYSDATE)";
}
