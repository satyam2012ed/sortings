package com.cg.employeemanintenance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.employeemanintenance.bean.EmployeeBean;
import com.cg.employeemanintenance.exception.EmployeeProblemException;
import com.cg.employeemanintenance.util.Dbutil;

public class EmployeeDaoImpl implements IEmployeeDAO {

	private Connection conn=null;
	@Override
	public boolean addEmployeeDetails(EmployeeBean employee) throws EmployeeProblemException {
		//db logic
		//get connection
		boolean status=false;
		try {
			conn=Dbutil.estabblishConnection();
			PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			preparedStatement.setString(1, employee.geteName());
			preparedStatement.setString(2, employee.getCity());
			preparedStatement.setLong(3, employee.getMobile());
			int storedStatus=preparedStatement.executeUpdate();
			
			if(storedStatus==1){
				
				status=true;
			}
			
		}  catch (SQLException e) {
			throw new EmployeeProblemException("problem : "+e.getMessage());
		}
		return status;
	}

}
