package com.cg.employeemanintenance.dao;

import com.cg.employeemanintenance.bean.EmployeeBean;
import com.cg.employeemanintenance.exception.EmployeeProblemException;


public interface IEmployeeDAO {
	public abstract boolean addEmployeeDetails(EmployeeBean employee) throws EmployeeProblemException;
}
