package com.capgemini.tcc.bean;

/*
 * Class name- ClinicBean
 * @author- Sushil Tiwari
 * created on - 17-Aug-2018
 * Description - This class is used for providing data storage space (Bean Class ) 
 */

public class PatientBean {
	private String name;	//Variable used to store name of patient
	private int age;		//variable used to store age of patient
	private String mobile;	//variable used to store mobile number of patient
	private String Description;	//variable used to store description of health of condition of patient
	public String getName() {		//Getter for name 
		return name;
	}
	public void setName(String name) {		//Setter for name
		this.name = name;
	}
	public int getAge() {			//Getter for age
		return age;
	}
	public void setAge(int age) {		//Setter for age
		this.age = age;
	}
	public String getMobile() {			//getter for mobile
		return mobile;
	}
	public void setMobile(String mobile) {		//setter for mobile
		this.mobile = mobile;
	}
	public String getDescription() {			//getter for description
		return Description;
	}
	public void setDescription(String description) {			//setter for description 
		Description = description;
	}
	public PatientBean(String name, int age, String mobile, String description) {
		super();
		this.name = name;
		this.age = age;
		this.mobile = mobile;
		Description = description;
	}
	public PatientBean(){}
}
