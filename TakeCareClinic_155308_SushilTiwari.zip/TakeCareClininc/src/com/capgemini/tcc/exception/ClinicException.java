package com.capgemini.tcc.exception;
/*
 * Class name- ClinicException
 * @author- Sushil Tiwari
 * created on - 17-Aug-2018
 * Description - This class is used to define user defined exceptions
 */
public class ClinicException extends Exception{
	public ClinicException() {
		// TODO Auto-generated constructor stub
	}
	public ClinicException(String message) {
		super(message);
	}
}
