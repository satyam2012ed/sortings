package com.capgemini.tcc.dbutil;

/*
 * Class name- DBUtil
 * @author- Sushil Tiwari
 * created on - 17-Aug-2018
 * Description - This class is used to make connections with the database 
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.capgemini.tcc.exception.ClinicException;


public class DBUtil {
static Connection conn=null;			//declaring a Connection variable
	
	public static Connection estabblishConnection() throws ClinicException{
		try{
		conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg228","training228"); //Calling the database drivers
		}
		catch(SQLException e){
			throw new ClinicException(e+"Error in database connection");
		}
		return conn;			//returning the connection object
	}
}
