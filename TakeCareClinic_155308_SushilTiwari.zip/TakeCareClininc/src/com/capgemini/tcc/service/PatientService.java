package com.capgemini.tcc.service;

/*
 * Class name- PatientService
 * @author- Sushil Tiwari
 * created on - 17-Aug-2018
 * Description - This class is implementing IPatientService interface to provide functionalities to it 
 */
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.ClinicException;

public class PatientService implements IPatientService {

	@Override							//Overriding the interface method
	public int addPatientDetails(PatientBean patient) throws ClinicException {	
		IPatientDAO dao=new PatientDAO();				//Creating Object of PatientDAO class 
		return dao.addPatientDetails(patient);
	}

}
