package com.capgemini.tcc.service;

/*
 * Interface name- IPatientService
 * @author- Sushil Tiwari
 * created on - 17-Aug-2018
 * Description - This is an interface for which will be implemented by patientService 
 */	
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.ClinicException;

public interface IPatientService {
 public abstract int addPatientDetails(PatientBean patient) throws ClinicException;
}
