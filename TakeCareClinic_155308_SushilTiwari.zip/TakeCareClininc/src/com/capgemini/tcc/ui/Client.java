package com.capgemini.tcc.ui;

/*
 * Class name- Client
 * @author- Sushil Tiwari
 * created on - 17-Aug-2018
 * Description - This is the main class for the  
 */

import java.util.Scanner;


import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.ClinicException;
import com.capgemini.tcc.service.PatientService;
public class Client {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int choice=0;										//Variable to store choices
		System.out.println("----------TAKECARE CLINIC------------");
		System.out.println();
		System.out.println("1. Make a Recharge.\n2. Exit"); //Asking what option to choose
		choice=scan.nextInt();
		try{
		switch(choice)										//Switching to the intended choice
		{
		case 1:
			System.out.print("Enter the name of the Patient: ");
			String name=scan.next();					//taking patient name
			System.out.print("Enter Patient Age: ");
			int age=scan.nextInt();							//taking patient age
			System.out.print("Enter Patient phone number: ");
			String mobile=scan.next();				//taking patient phone number
			System.out.print("Enter Description: ");
			String str=scan.next();							//taking description of disease
			PatientBean bean=new PatientBean();				//Object of Bean class to store details there
			bean.setAge(age);
			bean.setDescription(str);
			bean.setMobile(mobile);
			bean.setName(name);
			new PatientService().addPatientDetails(bean);
			break;
		case 2:												//If user choose to exit
			System.out.println("EXITING..!!!");
			break;
		default:											//Wrong Choice
			System.out.println("Invalid Option");	
		}
		}
		catch(ClinicException e){System.out.println(e);				//catching all the exceptions here
		}
		finally{
			scan.close();
			}
													//Closing reference to the scanner class object
	}	

}
