package com.capgemini.tcc.dao;


/*
 * Interface name- IQueryMapper
 * @author- Sushil Tiwari
 * created on - 17-Aug-2018
 * Description - This interface is used to store hard coded queries into variables 
 */
public interface IQueryMapper {
public static final String INSERT_INTO="INSERT INTO clinic_data VALUES(cl_seq.NEXTVAL,?,?,?,?,SYSDATE) ";
public static String GET_ID="SELECT cl_seq.NEXTVAL FROM DUAL";
}
