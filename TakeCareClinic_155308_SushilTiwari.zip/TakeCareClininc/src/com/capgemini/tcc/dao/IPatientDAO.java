package com.capgemini.tcc.dao;

/*
 * Interface name- IPatientDAO
 * @author- Sushil Tiwari
 * created on - 17-Aug-2018
 * Description - This is an interface for the patientDAO class 
 */
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.ClinicException;

public interface IPatientDAO {
public abstract int addPatientDetails(PatientBean patient) throws ClinicException;	//defining abstract method
}
