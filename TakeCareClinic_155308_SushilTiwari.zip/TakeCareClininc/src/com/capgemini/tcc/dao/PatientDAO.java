package com.capgemini.tcc.dao;

/*
 * Class name- PatientDAO
 * @author- Sushil Tiwari
 * created on - 17-Aug-2018
 * Description - This class is Primarily used for storing data inside the database 
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dbutil.DBUtil;
import com.capgemini.tcc.exception.ClinicException;

public class PatientDAO implements IPatientDAO {

	@Override
	public int addPatientDetails(PatientBean patient) throws ClinicException {
		Connection con=DBUtil.estabblishConnection();		//Establishing Connection
		PreparedStatement ps,ps1;					
		ResultSet rs=null;
		try{
			ps=con.prepareStatement(IQueryMapper.INSERT_INTO);		//Getting INSERT command Executed
			ps.setString(1,patient.getName());						//Putting name into the database
			ps.setInt(2, patient.getAge());							//Putting age into the database
			ps.setString(3,patient.getMobile());					//Putting mobile number into the database
			ps.setString(4, patient.getDescription());				//Putting description into the database
			ps.executeUpdate();										//reflecting the data into database
			ps1 = con.prepareStatement(IQueryMapper.GET_ID);		//Getting ID generated through database
			rs = ps1.executeQuery();								//Storing it in a result set
			rs.next();
			int a=rs.getInt(1)-1;
			s="Patient ID stored successfully for "+a;
			System.out.println("Patient ID stored successfully for "+a);		//Printing the final output message
		}
		catch(SQLException e)									//Catching if any exception occurs
		{ throw new ClinicException(e+"Cannot connect right now please check the database connection");}
		return 0;
	}
		public static String s=null;
		public static int a=0;
}
