package com.capgemini.tcc.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.ClinicException;
import com.capgemini.tcc.service.PatientService;

public class ClientTest {
	
	PatientBean bean=new PatientBean();
	PatientService serve=new PatientService();
	@Test
	public void test() {
		bean.setAge(20);
		bean.setDescription("headache");
		bean.setMobile("7011509288");
		bean.setName("ABCD");
			String s=PatientDAO.s;
			assertEquals("Patient ID stored successfully for "+PatientDAO.a,s);
			fail("Not yet implemented");
	}

}
